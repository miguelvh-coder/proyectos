
package PackageLab01;

import java.util.Date;


public class Transaccion {


Date Fecha;
int Origen = 0;
int Destino = 0;
double ValorOrigenAnte = 0, ValorOrigenDespues = 0,ValorDestinoAnte = 0,ValorDestinoDespues = 0;
Transaccion(int ori, int des, double valor){
date( ori, des, valor);
}
void date(int ori, int des, double valor){
Origen = ori;
Destino = des;
ValorOrigenAnte = valor;

}

}


