
package PackageLab01;



public class Usuario {
 public String Nombre, Apellido, Email;
  String Contraseña;
  int ID;
 public TipoUsuario Usuario; // TipoUsuario: Nuevo/Antiguo
 public int NTrans;
 
 Billetera MiBilletera = new Billetera();
 
 
 Usuario (){


 
         }


}
