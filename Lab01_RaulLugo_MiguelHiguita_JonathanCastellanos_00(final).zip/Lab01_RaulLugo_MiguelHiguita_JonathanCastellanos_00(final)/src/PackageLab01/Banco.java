
package PackageLab01;


public class Banco {
private final double TRochiCoin = 100; 



double getContenido (){
return TRochiCoin;

} 

    
}
