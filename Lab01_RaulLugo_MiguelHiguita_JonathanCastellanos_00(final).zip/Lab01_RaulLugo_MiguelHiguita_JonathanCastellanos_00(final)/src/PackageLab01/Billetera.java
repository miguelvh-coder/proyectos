
package PackageLab01;

public class Billetera {
public int BilleteraID;
Double Cantidad = 0.0;
    
}
